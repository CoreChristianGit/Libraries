This is revision #5 of the myFirstLibrary library.

This revision contains:
	Updated comments within the header and source files
	A delay input for the constructor and flash() function
	A new set of example code for circuits 1 and 2	

Example code included within the library pertains to circuits that can be found at https://core-electronics.com.au/tutorials/how-to-build-an-arduino-library.html 