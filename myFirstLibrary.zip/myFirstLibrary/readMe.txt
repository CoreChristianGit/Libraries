This is revision 2 of the myFirstLibrary
It works the same way but doesn't have a button argument so we can focus on attaching an interrupt to it 